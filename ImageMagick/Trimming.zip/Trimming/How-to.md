## option key

- shifting scripts become more aggressive
- other scripts: remove or overwrite *fewer* pixels
- append images script goes left to right in stead of top to bottom

## command key 

- shift scripts turn into erase scripts
- trim scripts restore original file dimensions, centering the output
- append images script reverses file order
