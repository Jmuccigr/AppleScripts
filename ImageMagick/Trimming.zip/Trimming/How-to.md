## option key

- shifting scripts become more aggressive
- other scripts: remove or overwrite *fewer* pixels
- append images script goes left to right in stead of top to bottom
- re-rez: ignore the "close enough" check (= force change)

## command key 

- shift scripts turn into erase scripts
- trim scripts restore original file dimensions, centering the output
- append images script reverses file order

## shift key

- reverse quicklook behavior (don't show for 3 or fewer)
