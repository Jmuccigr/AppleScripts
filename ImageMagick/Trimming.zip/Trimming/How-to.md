option key

- trim-only and shifting scripts become more aggressive
- other scripts: remove or overwrite *fewer* pixels

command key 

- shift scripts turn into erase scripts
